import  React,  { Component } from 'react';
import { Link } from 'react-router-dom';

//Components
import HeaderComponent from './headerComponent';

//Images
import icoCheck from '../assets/img/icoCheck.svg';
import icoRefresh from '../assets/img/icoRefresh.svg';

export default class SolicitudCreditoComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            value: 'coconut',
            pagos: [
                { nombre: 'Walmart Perisur', fecha: '09/07/2020', monto: '890', checked: false },
                { nombre: 'Maison Kayser Perisur', fecha: '09/07/2020', monto: '700', checked: false },
                { nombre: 'The BodyShop Perisur', fecha: '09/07/2020', monto: '1800', checked: false },
                { nombre: 'Moyo Perisur', fecha: '09/07/2020', monto: '300', checked: false }
            ],
        };
    
    }
    headerData = {
		mostrarFlecha: true,
		titulo: 'Diferir mis compras',
    };

    // state = {
    //     numCelular: '',
    //     codigo: '',
    //     terminosCondiciones: false,
    //     pagos: [
    //         { nombre: 'Walmart Perisur', fecha: '09/07/2020', monto: '890', estado: false },
    //         { nombre: 'Maison Kayser Perisur', fecha: '09/07/2020', monto: '700', estado: false },
    //         { nombre: 'The BodyShop Perisur', fecha: '09/07/2020', monto: '1800', estado: false },
    //         { nombre: 'Moyo Perisur', fecha: '09/07/2020', monto: '300', estado: false }
    //     ],
    //     total: ''
    // };

    handleCheckClick = (event) => {
        console.log(event)
        // this.setState({ checked: !this.state.checked });
    }

    // onChange = (e, boolean) => {
    //     let dataNombre = e.target.name;
    //     let dataValor = e.target.value;

    //     if(e.target.validity.valid){
    //         this.setState({
    //             [dataNombre]: boolean ? !this.state[dataNombre] : dataValor
    //         }, this.sendData);
    //     }
    // }

    // onChangePagos = (e, boolean) => {
    //     console.log(e.target.name);
    //     console.log(e.target.validity.valid);
    //     let dataNombre = e.target.name;
    //     let dataValor = e.target.value;

    //     if(e.target.validity.valid){
    //         this.setState({
    //             [dataNombre]: boolean ? !this.state[dataNombre] : dataValor
    //         }, this.sendData);
    //     }
    // }

    evaluaFormulario = () => {
        let valido = true;

        for(let dato of Object.keys(this.state)){
            if(!this.state[dato] || this.state[dato]  === ''){
                valido = false;
                break;
            }
        }

        return valido;
    }

    render(){
        return(
            <div className="cont-landing">
                <HeaderComponent headerData={ this.headerData }/>
                <div className="cont-title">
                    <div>Elige en <strong>cuántas semanas</strong> y <strong>qué cargos</strong> quieres diferir. </div>
                </div>
                <div className="cont-form u-flex-auto">
                    <span>¿Qué pagos quieres diferir?</span>
                    <div className="cont-table">
                        {this.state.pagos.map((pago, index) =>
                            <div className="element-table" key={index}>
                                <div className="checkbox-group">
                                    <label className="checkbox">
                                        <input 
                                            name={pago.nombre}
                                            type="checkbox"
                                            checked={pago.checked}
                                            onChange={ this.handleCheckClick }
                                        />
                                        <span></span>
                                    </label>
                                <span>{pago.nombre} <br></br> {pago.fecha}</span>
                                </div>
                                <div>
                                    <strong>{pago.monto}</strong>
                                </div>
                            </div>
                        )}
                        <div className="element-table total">
                            {/* <div className="checkbox-group">
                                <label className="checkbox">
                                    <input 
                                        name="terminosCondiciones"
                                        type="checkbox"
                                    />
                                    <span></span>
                                </label>
                                <span>Moyo Perisur <br></br> 09/07/2020</span>
                            </div> */}
                            <div>
                                <span>Total a diferir </span><strong>$2,690.00</strong>
                            </div>
                        </div>
                        
                        {/* <div className="checkbox-group">
                            <label className="checkbox">
                                <input 
                                    name="terminosCondiciones"
                                    type="checkbox"
                                    checked={ this.state.terminosCondiciones }
                                    onChange={ (e) => this.onChange(e, true) }
                                />
                                <span></span>
                            </label>
                            <small>He leído y acepto las <a className="u-color-primario" href="facebook.com">Condiciones del servicio y la Política de privacidad </a> de Banco Azteca.</small>
                        </div> */}

                    </div>
                    {/* <div className="input-group u-mb-1">
                        <label className="input-group__label">Ingresa tu número de celular</label>
                        <div className="input-group__input">
                            <input 
                                name="numCelular"
                                placeholder="Ej. 5524356890" 
                                pattern="[0-9]*"
                                onChange={ (e) => this.onChange(e, false) }
                                value={ this.state.numCelular }
                            />
                            {
                                this.state.numCelular !== '' ? <img src={ icoCheck } alt="icoCheck"/> : null
                            }
                        </div>
                    </div> */}
                    {/* {
                        this.state.numCelular !== '' ? 
                        <React.Fragment>
                            <label className="u-txt-medium u-py-1"><strong>Ingresa el código </strong>que enviamos a tu celular.</label>
                            <div className="input-group">
                                <label className="input-group__label">Código de verificación (7 dígitos)</label>
                                <div className="input-group__input">
                                    <input 
                                        name="codigo"
                                        placeholder="Ej. 1234567"
                                        pattern="[0-9]*"
                                        onChange={ (e) => this.onChange(e, false) }
                                        value={ this.state.codigo }
                                    />
                                    {
                                        this.state.codigo !== '' ? <img src={ icoCheck } alt="icoCheck"/> : null
                                    }
                                </div>
                                <small className="input-group__small">
                                    <img src={ icoRefresh } alt="icoRefresh"/>
                                    Reenviar código
                                </small>
                            </div>
                        </React.Fragment> : null
                    } */}
                </div>
                {/* <div className="checkbox-group">
                    <label className="checkbox">
                        <input 
                            name="terminosCondiciones"
                            type="checkbox"
                            checked={ this.state.terminosCondiciones }
                            onChange={ (e) => this.onChange(e, true) }
                        />
                        <span></span>
                    </label>
                    <small>He leído y acepto las <a className="u-color-primario" href="facebook.com">Condiciones del servicio y la Política de privacidad </a> de Banco Azteca.</small>
                </div> */}
                <div className="btn-center">
                    <Link to={{ pathname: '/tracker-credito' }} className={`btn ${ this.evaluaFormulario() ? 'btn--primario' : 'btn--desac'}` }>Continuar</Link>
                </div>
            </div>
        )
    }
}